// Framework/Math/MathUtils.cpp
#include "Math/MathUtils.hpp"

namespace CE::Math
    {
// All functions are inline/constexpr and defined in the header
// This file exists for build system consistency
    }