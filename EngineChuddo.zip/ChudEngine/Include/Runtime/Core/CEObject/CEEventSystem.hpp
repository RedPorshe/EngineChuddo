// Source/Runtime/Core/CEObject/CEEventSystem.hpp
#pragma once

#include "CEObject.hpp"
#include "CEDelegate.hpp"
#include "CEEvent.hpp"  // ��������� include
#include <unordered_map>
#include <string>
#include <memory>

namespace CE
    {
        // ������� ���������� ���������
    class CEEventSystem : public CEObject
        {
        public:
            CEEventSystem ();
            virtual ~CEEventSystem ();

            // ����������� ������������ �������
            template<typename EventType>
            void RegisterHandler ( const std::string & EventName, std::function<void ( std::shared_ptr<EventType> )> Handler )
                {
                auto delegate = GetOrCreateDelegate<EventType> ( EventName );
                delegate->Bind ( Handler );
                CE_DEBUG ( "EventSystem: Registered handler for event '{}'", EventName );
                }

            template<typename EventType, typename ClassType>
            void RegisterHandler ( const std::string & EventName, ClassType * Object, void ( ClassType:: * Method )( std::shared_ptr<EventType> ) )
                {
                auto delegate = GetOrCreateDelegate<EventType> ( EventName );
                delegate->Bind ( Object, Method );
                CE_DEBUG ( "EventSystem: Registered object handler for event '{}'", EventName );
                }

                // �������� �������
            template<typename EventType>
            void BroadcastEvent ( const std::string & EventName, std::shared_ptr<EventType> Event )
                {
                auto it = EventDelegates.find ( EventName );
                if (it != EventDelegates.end ())
                    {
                    if (auto delegate = std::dynamic_pointer_cast< CEDelegate<std::shared_ptr<EventType>> >( it->second ))
                        {
                        delegate->Broadcast ( Event );
                        CE_DEBUG ( "EventSystem: Broadcast event '{}' to {} handlers",
                                  EventName, delegate->GetNumBindings () );
                        }
                    }
                else
                    {
                    CE_WARN ( "EventSystem: No handlers registered for event '{}'", EventName );
                    }
                }

                // �������� ������������
            void UnregisterAllHandlers ( const std::string & EventName );
            void Clear ();

        private:
            std::unordered_map<std::string, std::shared_ptr<CEDelegateBase>> EventDelegates;

            template<typename EventType>
            std::shared_ptr<CEDelegate<std::shared_ptr<EventType>>> GetOrCreateDelegate ( const std::string & EventName )
                {
                auto it = EventDelegates.find ( EventName );
                if (it == EventDelegates.end ())
                    {
                    auto delegate = std::make_shared<CEDelegate<std::shared_ptr<EventType>>> ();
                    delegate->SetName ( "Delegate_" + EventName );
                    EventDelegates[ EventName ] = delegate;
                    return delegate;
                    }
                return std::dynamic_pointer_cast< CEDelegate<std::shared_ptr<EventType>> >( it->second );
                }
        };
    }