#pragma once
#include <vulkan/vulkan.h>
#include <memory>

namespace CE
    {
    class VulkanDevice;

    class CEVulkanBuffer
        {
        public:
            CEVulkanBuffer ();
            ~CEVulkanBuffer ();

            // ��������� �����������
            CEVulkanBuffer ( const CEVulkanBuffer & ) = delete;
            CEVulkanBuffer & operator=( const CEVulkanBuffer & ) = delete;

            // ��������� �����������
            CEVulkanBuffer ( CEVulkanBuffer && other ) noexcept;
            CEVulkanBuffer & operator=( CEVulkanBuffer && other ) noexcept;

            bool Create (
                VulkanDevice * device,
                VkDeviceSize size,
                VkBufferUsageFlags usage,
                VkMemoryPropertyFlags properties
            );

            void UploadData ( const void * data, VkDeviceSize size );
            void Destroy ();

            // �������
            VkBuffer GetBuffer () const { return m_Buffer; }
            VkDeviceMemory GetMemory () const { return m_Memory; }
            VkDeviceSize GetSize () const { return m_Size; }
            void * GetMappedData () const { return m_MappedData; }
            bool IsValid () const { return m_Buffer != VK_NULL_HANDLE; }

        private:
            VulkanDevice * m_Device = nullptr;
            VkBuffer m_Buffer = VK_NULL_HANDLE;
            VkDeviceMemory m_Memory = VK_NULL_HANDLE;
            VkDeviceSize m_Size = 0;
            void * m_MappedData = nullptr;
            bool m_IsMapped = false;
        };
    }